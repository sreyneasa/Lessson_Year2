<?php
require 'functions.php';
require 'database.php';
require 'router.php';


