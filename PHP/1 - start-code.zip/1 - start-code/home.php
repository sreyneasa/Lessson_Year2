<?php require "partials/head.php" ?>
<?php require "partials/nav.php" ?>

  <main>
    <div class="p-3">
      <!-- Replace with your content -->
     <p>Hello Home</p>
      <!-- /End replace -->
    </div>
  </main>
  
<?php require "partials/footer.php" ?>
