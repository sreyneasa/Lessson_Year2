<?php
// Get current date
date_default_timezone_set('Asia/Phnom_Penh');

