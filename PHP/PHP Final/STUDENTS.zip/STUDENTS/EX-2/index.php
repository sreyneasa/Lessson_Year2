<?php
require_once('template/header.php');
?>

<body>
    <?php
    require_once('form.php');
    ?>
</body>

</html>