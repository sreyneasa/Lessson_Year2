<?php
    $wep = ["Ronan", "Him", "Rady", "Hyacinthe"];

    // Add "Ratha" in the list of WEP trainers
    print_r($wep);
 
?>