<?php
    $wep = ["Ronan", "Him", "Rady", "Hyacinthe", "Ratha"];

    // Use a FOR loop to display the names of WEP trainers
 
?>