<?php
    // What is the difference between the operator '+' and the operator '.' ?
    // Read the error message and Correct th error in this program
    $number1 = "5ronan";
    $number2 = 2;
    echo  $number1 . $number2;
?>