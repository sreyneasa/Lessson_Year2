<?php
    // Instructions: execute this file and read the error message. Then correct the error.
    $number1 = 5
    echo $number1;
?>