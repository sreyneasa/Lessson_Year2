<?php

	// This associative array stores information about a fruit
    $fruit = ['name' => 'mango', 'quantity' => 15, 'price' => 10, 'country' => "Cambodia"];
	
	// TODO  : print the information about this fruit as follows:
    $output = "<quantity> <name> from <country> cost <price>$";   //  YOu need to change this line  !
	
    echo $output;
?>