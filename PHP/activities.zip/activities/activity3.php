<?php
    // Instructions: execute this file and read the error message. Then correct the error.
    myText = "Hello !";
    echo myText;
?>