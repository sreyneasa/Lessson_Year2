<?php
    $username = "Rady";
    // Replace XXXXXXXXX to display the value of $username
?>

Your username is <?php echo $username?>