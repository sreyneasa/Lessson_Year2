// let data = [
//     { name: 'Apple', stock: '20', price: '10$' },
//     { name: 'Banana', stock: '30', price: '15$' },
//     { name: 'Orange', stock: '40', price: '20$' },
//     { name: 'Pear', stock: '40', price: '30$' },
//     { name: 'Kivi', stock: '40', price: '2$' }

// ];
// function save() {
//     localStorage.setItem('data', JSON.stringify(data));
// }
// save()

// function load() {
//     data = JSON.parse(localStorage.getItem('data'))
// }

// function display_product() {
//     for (product of data) {
//         let card = document.createElement('div');
//         card.className = 'card p-3 mt-3';
//         let h3 = document.createElement('h3');
//         h3.textContent = product.name;
//         let pStock = document.createElement('span');
//         pStock.textContent = "Number stock:" + product.stock;
//         let pPrice = document.createElement('span');
//         pPrice.textContent = "Price" + product.price;

//         let btn = document.createElement('button');
//         btn.textContent = 'add to cart';
//         btn.addEventListener('click', addTocart);

//         card.appendChild(h3);
//         card.appendChild(pStock);
//         card.appendChild(pPrice);
//         card.appendChild(btn);
//         displayProduct.appendChild(card);

//     }
// }

// function addTocart(event) {
//     let cardProduct = event.target.parentElement;
//     let isProductNoExist = true;
//     for (product of card.children) {
//         console.log(product.children[0].textContent)
//         if (product.children[0].textContent === cardProduct.children[0].textContent);
//         isProductNoExist = false;
//     }
//     if (isProductNoExist) {

//         let productName = document.createElement('p');
//         productName.textContent = event.target.parentElement.children[0].textContent;
//         let productPrice = document.createElement('p');
//         productPrice.textContent = event.target.parentElement.children[2].textContent;
//         let quality = document.createElement('span');
//         quality.textContent = 'Quality 1';
//         let result = document.createElement('div');
//         result.className = 'card p-3 mt-3';

//         result.textContent = productName.textContent + ' : ' + productPrice.textContent + ' : ' + quality.textContent;

//         addList.appendChild(result)
//         addList.appendChild(card)
//     }


// }

// let addList = document.querySelector("#addlist")

// load();

// let displayProduct = document.querySelector('#displayProduct');
// display_product();


let data = [
    { name: 'Apple', stock: '20', price: '10$' },
    { name: 'Banana', stock: '30', price: '15$' },
    { name: 'Orange', stock: '40', price: '20$' },
    { name: 'Pear', stock: '40', price: '30$' },
    { name: 'Kivi', stock: '40', price: '2$' }
];

function save() {
    localStorage.setItem('data', JSON.stringify(data));
}

function load() {
    data = JSON.parse(localStorage.getItem('data'));
}

function display_products() {
    let displayProduct = document.querySelector('#displayProduct');
    displayProduct.innerHTML = '';
    for (let product of data) {
        let card = document.createElement('div');
        card.className = 'card p-3 mt-3';
        let h3 = document.createElement('h3');
        h3.textContent = product.name;
        let pStock = document.createElement('span');
        pStock.textContent = 'Number in stock: ' + product.stock;
        let pPrice = document.createElement('span');
        pPrice.textContent = 'Price: ' + product.price;

        let btn = document.createElement('button');
        btn.textContent = 'Add to cart';
        btn.addEventListener('click', addToCart);

        card.appendChild(h3);
        card.appendChild(pStock);
        card.appendChild(pPrice);
        card.appendChild(btn);
        displayProduct.appendChild(card);
    }
}

function addToCart(event) {
    let cardProduct = event.target.parentElement;
    let isProductNoExist = true;
    let addList = document.querySelector('#addlist');
    for (let product of addList.children) {
        if (product.textContent.includes(cardProduct.children[0].textContent)) {
            isProductNoExist = false;

        }
    }
    if (isProductNoExist) {
        let productName = document.createElement('p');
        productName.textContent = cardProduct.children[0].textContent;
        let productPrice = document.createElement('p');
        productPrice.textContent = cardProduct.children[2].textContent;
        let quantity = document.createElement('span');
        quantity.textContent = 'Quantity: 1';
        let result = document.createElement('div');
        result.className = 'card p-3 mt-3';
        result.textContent = `${productName.textContent} : ${productPrice.textContent} : ${quantity.textContent}`;

        addList.appendChild(result);
    }
}

function show() {
    load();
    display_products();
}

show();