const createPoster = () => {
   // TODO: Create poster here
}

// Main code 
const container = document.querySelector('.container');
// TODO:  Call function to create 10 poster here
