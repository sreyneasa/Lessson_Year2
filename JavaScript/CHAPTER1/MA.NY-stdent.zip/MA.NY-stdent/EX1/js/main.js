let text = "hello world [JavaScript] we [are] strong!";
let newText= text.replace("[JavaScript]","").replace("[are]","");
console.log(newText)

// output: hello world we strong!