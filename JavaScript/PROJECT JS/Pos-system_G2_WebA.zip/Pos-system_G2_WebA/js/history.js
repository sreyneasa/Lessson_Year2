// let header = document.querySelector('header');
// let container = document.querySelector('.container');
// let openTab = document.querySelector('.box3');
// let productTab = document.querySelector('.box1');
// let history = document.querySelector('.history');

// openTab.addEventListener('click', ()=>{
//     container.style.display = 'none';
//     history.style.display = 'block';
// });

