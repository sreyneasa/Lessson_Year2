
let btnEvent = () => {
    // your code here
}
let paraEvent = () => {
    // your code here
}
let divEvent = () => {
    // your code here
}

const btn = // your code here
const para = // your code here
const div = // your code here

btn.addEventListener('click', btnEvent);
para.addEventListener('click', paraEvent);
div.addEventListener('click', divEvent);
